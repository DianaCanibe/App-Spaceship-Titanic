import React from "react";
import { View, Text, Controller, TextInput } from "react-native";

const ModelInput = (props) => { 
      return (
        <Controller
        control={props.control}
        rules={{
         required: true,
        }}
        render={({ field: { onChange, onBlur, value } }) => (
          <TextInput
            style={styles.input}
            onBlur={onBlur}
            onChangeText={onChange}
            value={value}
          />
        )}
        name={props.name}
      />
      );
}


export default ModelInput;