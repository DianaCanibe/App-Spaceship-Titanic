import { StatusBar } from 'expo-status-bar';
import React from "react";
import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView, TextInput } from "react-native";
import {  Button, Alert } from "react-native";
import { useForm, Controller } from "react-hook-form";
import { useEffect, useState } from 'react';
import Constants from "expo-constants";
import ModelInput from "./components/ModelInput";


export default function App() {
  const [data, setData] = useState([]);
  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      CryoSleep:'',
      Age:'',
      VIP:'',
      RoomService:'',
      FoodCourt:'',
      ShoppingMall:'',
      Spa:'',
      VRDeck:'',
      total_expenses:'',
      no_expenses:'',
      cabin_deck:'',
      cabin_number:'',
      group:'',
      HomePlanet_Earth:'', 
      HomePlanet_Mars: '',
      cabin_side_P: '',  
      cabin_side_S: ''
    }
  });
  const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({control})
  };

  const onSubmit = async (data) => {
    //Aquí debes cambiar por la ip de donde se encuentre el servidor
    const response = await fetch('52.23.186.209/modelo', requestOptions);
    const json = await response.json();
    console.log(data);
    console.log(json);    
  }
  return (
    
    <View style={{marginTop:Constants.statusBarHeight}}>
      <ModelInput name="CryoSleep" control={control} />
      {errors.CryoSleep && <Text>This is required.</Text>}
      <ModelInput name="Age" control={control} />
      {errors.Age && <Text>This is required.</Text>}
      <ModelInput name="VIP" control={control}/>
      {errors.VIP && <Text>This is required.</Text>}
      <ModelInput name="RoomService" control={control} />
      {errors.RoomService && <Text>This is required.</Text>}
      <ModelInput name="FoodCourt" control={control}/>
      {errors.FoodCourt && <Text>This is required.</Text>}
      <ModelInput name="ShoppingMall" control={control} />
      {errors.ShoppingMall && <Text>This is required.</Text>}
      <ModelInput name="Spa" control={control}/>
      {errors.Spa && <Text>This is required.</Text>}
      <ModelInput name="VRDeck" control={control}/>
      {errors.VRDeck && <Text>This is required.</Text>}
      <ModelInput name="total_expenses" control={control}/>
      {errors.total_expenses && <Text>This is required.</Text>}
      <ModelInput name="no_expenses" control={control}/>
      {errors.no_expenses && <Text>This is required.</Text>}
      <ModelInput name="cabin_deck" control={control} />
      {errors.cabin_deck && <Text>This is required.</Text>}
      <ModelInput name="cabin_number" control={control} />
      {errors.cabin_number && <Text>This is required.</Text>}
      <ModelInput name="group"  control={control} />
      {errors.group && <Text>This is required.</Text>}
      <ModelInput name="HomePlanet_Earth" control={control} />
      {errors.HomePlanet_Earth && <Text>This is required.</Text>}
      <ModelInput name="HomePlanet_Mars" control={control} />
      {errors.HomePlanet_Mars && <Text>This is required.</Text>}
      <ModelInput name="cabin_side_P" control={control} />
      {errors.cabin_side_P && <Text>This is required.</Text>}
      <ModelInput name="cabin_side_S" control={control}/>
      {errors.cabin_side_S && <Text>This is required.</Text>}

      <Button title="Submit" onPress={handleSubmit(onSubmit)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});
